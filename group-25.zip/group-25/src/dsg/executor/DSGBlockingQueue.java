package dsg.executor;

public class DSGBlockingQueue<V>{

	// ##################
	// # INITIALIZATION #
	// ##################

    /* Constructor */
    public DSGBlockingQueue(){
        // TODO implement constructor
    }

	// ##########
	// # ACCESS #
	// ##########
    
    
    /* Inserts element to queue (non blocking operation) */
    public void insert(V value) {
    	// TODO implement method
    }

    /* Retrieves element from head of the queue - wait if the queue is empty (blocking operation) */
    public V retrieve() throws InterruptedException {
    	// TODO implement method
        return null;
    }
    
    /* Size of the BlockingQueue */
    public int size() {
    	// TODO implement method
        return 0;
    }
}